// CreateStudent Component for add new student

// Import Modules
import React, { useState, useEffect } from "react";
import axios from 'axios';
import StudentForm from "./StudentForm";
import { useNavigate } from "react-router-dom";
// CreateStudent Component
const CreateStudent = () => {
const [formValues, setFormValues] =
	useState({ name: '', email: '', rollno: '', photo:'' })
// onSubmit handler

let navigate=useNavigate();
const onSubmit = studentObject => {
	axios.post(
'https://reactdbapiapp.azurewebsites.net/students/create-student',
	studentObject)
	.then(res => {
		if (res.status === 200){
		alert('Student successfully created')
		navigate("/student-list");
		}
		else
		Promise.reject()
	})
	.catch(err => alert('Something went wrong'))
}
	
// Return student form
return(
	<StudentForm initialValues={formValues}
	onSubmit={onSubmit}
	enableReinitialize>
	Create Student
	</StudentForm>
)
}

// Export CreateStudent Component
export default CreateStudent
