module.exports = {
    db: 'mongodb://reactappdb:UUfIU49WNMS3SXQnnmzlyZMF3NtAQDfnFdgSyVWx1ExOsZzfOfwNIdT7C8LLUCDcmTsGdZvrujC4t0Th8ke2tA==@reactappdb.mongo.cosmos.azure.com:10255/?ssl=true&retrywrites=false&maxIdleTimeMS=120000&appName=@reactappdb@'
    };
    